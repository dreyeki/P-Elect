import fs from 'node:fs'; import path from 'node:path';
const ROOT = path.resolve(import.meta.dirname, '..');
globalThis.fetch = async (u) => ({ ok: true, status: 200, json: async () => JSON.parse(fs.readFileSync(path.join(ROOT, String(u).replace(/^\.\//, '')), 'utf8')) });
const { loadData } = await import('../src/data/loader.js');
const { createGame } = await import('../src/core/GameState.js');
const { advance } = await import('../src/core/TurnEngine.js');
const { initScales, word } = await import('../src/util/scale.js');
const E = await import('../src/systems/ElectionSystem.js');
const Ending = await import('../src/systems/EndingSystem.js');
const { Rng } = await import('../src/core/Rng.js');
const { clamp05 } = await import('../src/core/Formula.js');

const data = await loadData(); initScales(data.scales);
let fails = 0;
const ok = (c, m) => { console.log((c ? 'OK   ' : 'FAIL ') + m); if (!c) fails++; };

const state = createGame(data, {
  seedStr: 'ELEC0001', name: '王明德', gender: 'x', startId: 'aide',
  backgroundId: 'local', education: '大學', homeDistrict: 'TNN-04', party: 'PDA',
  ideology: { centralization: 0, unification: -2, marketFreedom: -1, progressivism: 2, immigration: 0, environment: 1, militaryAutonomy: 1, directDemocracy: 2 },
});

// 沒有在選的人不該被放慢成一週一次（v0.6.0）
let weekSeen = false;
for (let i = 0; i < 9; i++) { advance(state, data); if (state.meta.scale === 'week') weekSeen = true; }
ok(!weekSeen && state.meta.scale === 'month',
  `選前兩個月還沒登記參選，回合維持一個月（目前 ${state.meta.scale}，${state.meta.year}/${state.meta.month}）`);

// 可參選職位
const { months, sched } = E.monthsUntilElection(state, data);
ok(months <= 2, `已經走到選前 ${months} 個月`);
const runs = E.availableRuns(state, data, sched);
ok(runs.length > 0, `可參選職位 ${runs.length} 個：${runs.map((r) => r.name).join('、')}`);
// 開局第一場選舉就選得到議員（v0.6.0）
ok(runs.some((r) => r.type === 'councilor'), '素人在第一場選舉就選得到縣市議員');

// 真的決定要選了，時間才切成週
state.election = { phase: 'campaign' };
E.enterCampaignScale(state);
ok(state.meta.scale === 'week', '登記參選之後才切成週回合');
advance(state, data);
ok(state.meta.scale === 'week', '選戰期間維持週回合');
state.election = null;
advance(state, data);
ok(state.meta.scale === 'month', '選完之後自己切回月回合');

// 村里長是無黨籍選舉：沒有初選，對手也沒有黨籍（v0.6.0）
const villageRun = { type: 'villageHead', scopeId: state.player.homeDistrict,
  name: '村里長', level: data.elections.levels.villageHead };
const vPri = E.buildPrimary(state, data, villageRun, new Rng(1, 0));
ok(vPri.skip, `村里長不用初選：${vPri.msg}`);
const vOpps = E.makeOpponents(state, data, villageRun, new Rng(2, 0));
ok(vOpps.length > 0 && vOpps.every((c) => c.party === 'IND'),
  `村里長的 ${vOpps.length} 位對手全部都是無黨籍，背後沒有派系`);

// 初選：多競爭者、可以先去談
const rng = new Rng(state.meta.seed, 4242);
const pri = E.buildPrimary(state, data, runs[0], rng);
ok(!pri.skip && pri.rivals.length >= 1, `初選對手 ${pri.rivals.length} 位：${pri.rivals.map((r) => `${r.name}（${r.factionName}）`).join('、')}`);
const beforeMember = pri.me.member;
state.player.politicalCapital = 200;
const fac = state.parties[state.player.party].factions[0];
fac.favor = 5;
const lob = E.lobbyFaction(state, data, pri, fac.id, new Rng(3, 0));
ok(lob.ok, `拜會派系：${lob.msg}`);
ok(pri.lobbied.length === 1, '談過的派系不能再談第二次');
const lob2 = E.lobbyFaction(state, data, pri, fac.id, new Rng(3, 0));
ok(!lob2.ok, '重複拜會會被擋下來');
const res = E.resolvePrimary(state, data, pri, rng);
ok(typeof res.won === 'boolean' && res.field.length === pri.rivals.length + 1,
  `初選開票：${res.field.map((x) => `${x.name} ${(x.share * 100).toFixed(1)}%`).join('　')}`);
ok(Math.abs(res.field.reduce((a, x) => a + x.share, 0) - 1) < 1e-6, '初選得票率總和為 1');

// 對手與計票
const run = runs.find((r) => r.type === 'councilor') ?? runs[0];
const opps = E.makeOpponents(state, data, run, rng);
ok(opps.length >= 2, `產生 ${opps.length} 位對手`);
const me = { isPlayer: true, name: state.player.name, party: state.player.party, fame: state.player.fame, stigma: state.player.stigma, attrs: state.player.attrs };
const r1 = E.computeVotes(state, data, run, [me, ...opps], rng);
const sum = r1.results.reduce((a, x) => a + x.share, 0);
ok(Math.abs(sum - 1) < 1e-6, `得票率總和 = ${sum.toFixed(6)}`);
ok(r1.results.every((x) => x.votes > 0 && Number.isFinite(x.votes)), '所有候選人得票為有限正數');
ok(r1.results.every((x) => x.noise >= 0.98 && x.noise <= 1.05), `隨機乘數落在 0.98–1.05（實際 ${r1.results.map((x) => x.noise.toFixed(3)).join(' ')}）`);

// 隨機乘數確實造成差異
const r2 = E.computeVotes(state, data, run, [me, ...opps], new Rng(state.meta.seed, 9999));
const diff = Math.abs(r1.results[0].share - r2.results.find((x) => x.candidate === r1.results[0].candidate).share);
ok(diff > 0, `不同隨機序列下同一候選人的得票率有差異（${(diff * 100).toFixed(3)} 個百分點）`);

// 基層組織確實提升得票
// 用固定的隨機序列比較，才不會被 0.98~1.05 的乘數干擾
for (const d of Object.values(state.districts)) d.playerGrassroots = 0;
const before = E.computeVotes(state, data, run, [me, ...opps], new Rng(7, 0)).results.find((x) => x.candidate.isPlayer).share;
for (const d of Object.values(state.districts)) d.playerGrassroots = 5;
const r3 = E.computeVotes(state, data, run, [me, ...opps], new Rng(7, 0));
const after = r3.results.find((x) => x.candidate.isPlayer).share;
ok(after > before, `基層組織拉滿後得票率由 ${(before * 100).toFixed(2)}% 升到 ${(after * 100).toFixed(2)}%`);

// 熱情度確實影響投票率
for (const d of Object.values(state.districts)) d.playerGrassroots = 0;
const P = state.pops;
const baseline = E.computeVotes(state, data, run, [me, ...opps], new Rng(11, 0)).results.find((x) => x.candidate.isPlayer).votes;
for (let i = 0; i < P.n; i++) P.enthusiasm[i] = 0;
const cold = E.computeVotes(state, data, run, [me, ...opps], new Rng(11, 0)).results.find((x) => x.candidate.isPlayer).votes;
ok(cold < baseline, `支持者熱情歸零後票數由 ${baseline.toLocaleString()} 掉到 ${cold.toLocaleString()}`);

// SNTV 與不分區
const seats = data.byId.district[run.scopeId]?.seats ?? 5;
const want = Math.min(seats, r1.results.length);
ok(E.resolveSNTV(r1.results, seats).length === want, `SNTV 從 ${r1.results.length} 位候選人中取出 ${want} 名當選人（應選 ${seats} 席）`);
const pl = E.partyListSeats({ PDA: 0.34, CRP: 0.33, TPL: 0.12, NGF: 0.06, TWR: 0.03, GSP: 0.02 }, 34, 0.05);
const plSum = Object.values(pl).reduce((a, b) => a + b, 0);
ok(plSum === 34, `不分區配出 ${plSum} 席，5% 門檻下 TWR/GSP 未分配到（${JSON.stringify(pl)}）`);
ok(!('TWR' in pl) && !('GSP' in pl), '未達門檻政黨確實被排除');

// 立委選區覆蓋
const legTotal = data.elections.legislatorDistricts.length;
ok(legTotal === 73, `區域立委選區共 ${legTotal} 個`);
const cov = {};
for (const l of data.elections.legislatorDistricts) for (const p of l.parts) cov[p.districtId] = (cov[p.districtId] ?? 0) + p.weight;
const badCov = Object.entries(cov).filter(([, v]) => Math.abs(v - 1) > 0.08);
ok(badCov.length === 0, `所有一般選區的權重加總都接近 1（異常 ${badCov.length} 個）`);


/* ─────────── v0.5.2：開完票之後不能再被問一次 ─────────── */
console.log('\n── 選舉季的收尾 ──');
const mkE = (seed) => createGame(data, {
  seedStr: seed, name: '王明德', gender: 'x', startId: 'aide',
  backgroundId: 'local', education: '大學', homeDistrict: 'TNN-04', party: 'PDA',
  ideology: {}, china: {},
});
{
  const s2 = mkE('DONE1');
  s2.meta.year = 2026; s2.meta.month = 11; s2.meta.scale = 'week';
  const sched = { year: 2026, month: 11 };
  const run = { type: 'village', scopeId: s2.player.homeDistrict, name: '里長', level: { deposit: 0 } };
  s2.election = { phase: 'campaign', sched, run, weeksLeft: 0 };
  const outcome = { won: true, results: [{ candidate: { isPlayer: true, name: s2.player.name }, votes: 1200, share: 0.42 }] };
  E.applyResult(s2, data, run, outcome, sched);
  ok(s2.election === null, '結算之後 election 被清掉');
  ok(s2.flags['elecDone_2026'] === true, '2026 年的選舉被標記成已經結束');
  ok(!('elecDone_undefined' in s2.flags), '不會寫出 elecDone_undefined 這種旗標');
  ok(s2.player.role === 'village', `當選之後身分變成里長：${s2.player.role}`);

  // 模擬 checkElection 的判斷：同一年不該再被問第二次
  const wouldAskAgain = (st) => {
    const { months, sched: sc } = E.monthsUntilElection(st, data);
    if (!sc) return false;
    if (st.election) return false;
    return months !== null && months <= 2 && st.meta.scale === 'week' && !st.flags['elecDone_' + sc.year];
  };
  ok(!wouldAskAgain(s2), '開完票的下一週不會再跳一次「是否參選」');

  // 沒有結算過的世界仍然應該問
  const s3 = mkE('DONE2');
  s3.meta.year = 2026; s3.meta.month = 11; s3.meta.scale = 'week'; s3.election = null;
  const nxt = E.monthsUntilElection(s3, data);
  ok(nxt.sched ? !s3.flags['elecDone_' + nxt.sched.year] : true, '還沒選過的年度不會被誤標成已結束');

  // 落選也一樣要收尾
  const s4 = mkE('DONE3');
  s4.election = { phase: 'campaign', sched, run, weeksLeft: 0 };
  E.applyResult(s4, data, run,
    { won: false, results: [{ candidate: { isPlayer: true }, votes: 300, share: 0.11 }] }, sched);
  ok(s4.flags['elecDone_2026'] === true, '落選同樣會結束這一年的選舉季');
  ok(!wouldAskAgain(s4), '落選之後也不會再被問一次');
}

/* ─────────── v0.5.4：初選落敗之後的三條路 ─────────── */
console.log('\n── 初選落敗之後 ──');
{
  const base = () => {
    const g = mkE('QUIT');
    g.meta.year = 2026; g.meta.month = 11; g.meta.scale = 'week';
    g.election = {
      phase: 'primary', sched: { year: 2026, month: 11 },
      run: { type: 'councilor', name: '市議員', level: {} },
      primaryWon: false,
      primaryField: [{ name: '洪菁宜', isPlayer: false, share: 0.53 }, { name: g.player.name, isPlayer: true, share: 0.47 }],
    };
    return g;
  };
  // 留下來輔選
  const a = base();
  a.flags['elecDone_' + a.election.sched.year] = true;
  E.afterPrimaryLoss(a, data, new Rng(1, 0));
  a.election = null;
  ok(a.flags['elecDone_2026'] === true && !a.flags.retired, '留下來輔選：選舉季收掉，人還在');

  // 心灰意冷退出：選舉季要一起收掉，否則結算完還會被問一次要不要參選
  const b = base();
  b.flags['elecDone_' + b.election.sched.year] = true;
  b.flags.quitAfterPrimary = true;
  b.election = null;
  const sum = Ending.summarize(b, data);
  const ep = Ending.epilogue(b, data, sum, new Rng(2, 0));
  ok(b.flags['elecDone_2026'] === true, '心灰意冷退出：這一年的選舉季也收掉了');
  ok(sum && Ending.TIER_NAME[sum.tier], `結算得出等第：${Ending.TIER_NAME[sum.tier]}`);
  ok(ep.paras.length > 0, `事後談有 ${ep.paras.length} 段`);
  ok(b.flags.quitAfterPrimary === true, '結算頁看得到「是在開票那晚決定的」這個標記');
  const wouldAsk = (st) => {
    const { months, sched: sc } = E.monthsUntilElection(st, data);
    if (!sc || st.election) return false;
    return months !== null && months <= 2 && st.meta.scale === 'week' && !st.flags['elecDone_' + sc.year];
  };
  ok(!wouldAsk(b), '退出之後不會再被問一次要不要參選');
}

console.log(fails ? `\n${fails} 項失敗` : '\n選舉系統全部通過');
process.exit(fails ? 1 : 0);
